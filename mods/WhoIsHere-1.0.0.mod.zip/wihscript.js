window.get_people_here = function() {
    try {
        if (V.pc.in_encounter())
            T.WISpeople = [...V.encounter.partners().map(x => x.name), ...V.encounter.witnesses.map(x => x.name)];
        else if (V.hangout)
            T.WISpeople = [V.hangout.partner];
        else if (V.tablemates && ["RiverRat", "SummitMarket", "ChamberlainHall"].includes(V.location))
            T.WISpeople = [...V.tablemates];
        else if (V.parkmates && ["UniMall"].includes(V.location))
            T.people = [...V.parkmates];
        else {
            T.WISpeople = [...V.peopleatlocation];
            if (V.arcade && V.arcade.competitors && V.location == "Arcade")
                for (let comp of V.arcade.competitors)
                    if (!T.WISpeople.includes(comp))
                        T.WISpeople.push(comp);
        }
    } catch {
        return
    }

}

window.who_is_here = function() {
    window.get_people_here()
    const truncatedArray = (arr, length) => arr.length > length ? arr.slice(0, length) : arr;
    if (!T.WISpeople) return ""
    let known = T.WISpeople.filter(x => setup.people.is_known(x)).map(x => '<<anonorfullname \"' + x + '\">>');
    let unknown = T.WISpeople.filter(x => !setup.people.is_known(x))
    unknown = truncatedArray(unknown, 3).map(x => '<<anonorfullname \"' + x + '\">>');
    return "<br>" + setup.and(known.concat(unknown)) + (unknown.length < 3 ? "在这里。" : "等人在这里。")
}